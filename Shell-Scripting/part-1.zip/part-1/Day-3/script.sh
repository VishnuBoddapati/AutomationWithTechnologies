#!/bin/bash
echo $#
