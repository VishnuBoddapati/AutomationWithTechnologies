#!/bin/bash

#echo "$*"
#echo "$@"
sudo systemctl start nginx
echo $?
