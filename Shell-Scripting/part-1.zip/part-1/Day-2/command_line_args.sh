#!/bin/bash
<< mycom
echo "The current shell scriptin is: $0"
secon_cmd_args=$2

echo "$secon_cmd_args=$2"
echo "$5"

yum install $1
mycom

echo "${11}"
