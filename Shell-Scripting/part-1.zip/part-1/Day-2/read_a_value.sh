#!/bin/bash

echo -n "Enter pkg name: "
read 
echo "The input value is: ${REPLY}"
