#!/bin/bash

if [ -s x ]
then
  echo "File has content"
else
   echo "No Content "
fi
