#!/bin/bash

if [ -d "/home/ec2-user/May_2019/Day-4"  ]
then
    echo "Given is directory"
else
    echo "Given is not a directory"
fi
