#!/bin/bash
#Author: Narendra
<< mycom
echo "Welcome to shell scripting"
echo "This is frist class"
mycom
#echo -e "Welcome to shell scripting \nThis is frist class"
echo -n "Today date is: "
date
