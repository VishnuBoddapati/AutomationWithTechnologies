#!/bin/bash
x=6
y=7.9
p=45;q=75.9

#echo "x=${x}"
#echo "y=${y}"
echo "The value of x is: $x"
