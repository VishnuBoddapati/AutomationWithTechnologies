# AWS-Provisioning-using-Ansible-
Playbooks for AWS
