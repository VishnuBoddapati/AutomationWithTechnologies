S_NO,IAM_User_Name,Console_Access,Programatic_Access,Policy_Arn
1,dowithpython@gmail.com,Yes,No,arn:aws:iam::aws:policy/AdministratorAccess
2,dowithscripting@gmail.com,Yes,Yes,arn:aws:iam::aws:policy/AmazonS3FullAccess
3,PNKMR1221@gmail.com,No,Yes,arn:aws:iam::aws:policy/IAMFullAccess
